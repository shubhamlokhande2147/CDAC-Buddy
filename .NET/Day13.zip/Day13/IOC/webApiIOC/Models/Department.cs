namespace BOL;
public class Department{
    public int did{get;set;}
    public string dname{get;set;}
    public string location{get;set;}
    
}