using BOL;
using Microsoft.EntityFrameworkCore.Migrations.Operations;

public interface IDeptRepositoty {
     
     public List<Department> getAll();

}