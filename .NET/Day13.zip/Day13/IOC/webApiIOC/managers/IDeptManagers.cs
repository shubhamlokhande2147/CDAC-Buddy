using BOL;

public interface IDeptManagers{
    public List<Department> getAll();
}