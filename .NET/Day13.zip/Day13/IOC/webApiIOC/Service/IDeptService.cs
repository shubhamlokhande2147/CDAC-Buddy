using BOL;

public interface IDeptService
{
    public List<Department> getAllProduct();
   
}