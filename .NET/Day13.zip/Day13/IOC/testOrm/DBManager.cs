namespace DAL;
using BOL;

public class DBManager{
    public List<Department> Getall(){
        List<Department>dlist=new List<Department>();
        return dlist;
    }
}