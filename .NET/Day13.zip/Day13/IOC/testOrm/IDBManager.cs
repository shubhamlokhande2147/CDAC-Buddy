namespace DAL;
using BOL;

public interface IDBManager{
    public List<Department> Getall();
}