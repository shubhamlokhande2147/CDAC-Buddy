using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using EmployeeApp.Models;
using BLL;
using BOL;

namespace EmployeeApp.Controllers;

public class EmployeeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public EmployeeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        List<Employee> allemp = Manager.GetAll();
        ViewData["allemp"] = allemp;
        return View();
    }

     public IActionResult Insert()
    {
   
        return View();
    }
    [HttpPost]
    public IActionResult Insert(int id1,string name ,string email, int contact)
    {
        Manager.Insert(id1,name,email,contact);
        return Redirect("/Employee/Index");
    }
     public IActionResult Edit()
    {
   
        return View();
    }
    [HttpPost]
    public IActionResult Edit(int id1,string name ,string email, int contact)
    {
        ViewBag["id"]=id1;
        Manager.Edit(id1,name,email,contact);
        return Redirect("/Employee/Index");
    }
    public IActionResult Delete()
    {
   
        return View();
    }
    [HttpPost]
    public IActionResult Delete(int id1,string name ,string email, int contact)
    {
        Manager.Delete(id1);
        return Redirect("/Employee/Index");
    }

    public IActionResult Privacy()
    {
        return View();
    }

    
    public IActionResult Employee()
    {
        return Redirect("/Employee/Index");
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
