namespace BOL;

public class Employee
{
   public int Id{get;set;}
   public string Name{get;set;}
   public string Email{get;set;}
   public int Contact{get;set;}

   public Employee()
   {
    this.Id = 1;
    this.Name = "Proxy";
    this.Email = "proxy@gmail.com";
    this.Contact = 1234567890;
   }
    
     public Employee(int id,string name,string email,int contact)
   {
    this.Id = id;
    this.Name = name;
    this.Email = email;
    this.Contact = contact;
   }
}