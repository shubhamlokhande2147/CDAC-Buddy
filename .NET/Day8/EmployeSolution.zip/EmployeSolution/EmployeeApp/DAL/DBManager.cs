namespace DAL;
using MySql.Data.MySqlClient;
using BOL;
using Org.BouncyCastle.Asn1.Cms;

public class DBManager
{
    public static string ConString = @"server=192.168.10.150;port=3306;user=dac52;password=welcome;database=dac52";

      public static List<Employee> GetAll()
      {
         List<Employee> allemp = new List<Employee>();

         MySqlConnection con = new MySqlConnection();
         con.ConnectionString = ConString;
         string query = "Select * from Employees";

         try{

            MySqlCommand cmd = new MySqlCommand(query,con);
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = query;
            MySqlDataReader reader = cmd.ExecuteReader();

            while(reader.Read())
            {
              int id = int.Parse(reader["Id"].ToString());
              string nm = reader["Name"].ToString();
              string em = reader["Email"].ToString();
              int ct = int.Parse(reader["Contact"].ToString());

              Employee e1 = new Employee(id,nm,em,ct);
              if(e1 !=null)
              {
                 allemp.Add(e1);
              }

            }

         }catch(Exception e)
         {
            Console.WriteLine(e.Message);
         }finally{
            con.Close();
         }

          return allemp;

      }


      public static  void Insert(int id1,string name ,string email, int contact)
      {
         MySqlConnection con = new MySqlConnection();
         con.ConnectionString = ConString;
         string query = "Insert into Employees values(@id,@name,@email,@contact)";
         Console.WriteLine("db",contact);
         try{

            MySqlCommand cmd = new MySqlCommand(query,con);
            cmd.Parameters.AddWithValue("@id",id1);
            cmd.Parameters.AddWithValue("@name",name);
            cmd.Parameters.AddWithValue("@email",email);
            cmd.Parameters.AddWithValue("@contact",contact);

            cmd.Connection = con;
            con.Open();
            cmd.CommandText = query;
            cmd.ExecuteNonQuery();
            
         }catch(Exception e)
         {
            Console.WriteLine(e.Message);
         }finally{
            con.Close();
         }

      
      }


    public static void Edit(int id1,string name ,string email, int contact)
    {
         MySqlConnection con = new MySqlConnection();
         con.ConnectionString = ConString;

         string query = "Update Employees set Name=@name,Email=@email,Contact=@contact where Id=@id";
         Console.WriteLine("db",contact);
         try{

            MySqlCommand cmd = new MySqlCommand(query,con);
            cmd.Parameters.AddWithValue("@id",id1);
            cmd.Parameters.AddWithValue("@name",name);
            cmd.Parameters.AddWithValue("@email",email);
            cmd.Parameters.AddWithValue("@contact",contact);

            cmd.Connection = con;
            con.Open();
            cmd.CommandText = query;
            cmd.ExecuteNonQuery();
            
         }catch(Exception e)
         {
            Console.WriteLine(e.Message);
         }finally{
            con.Close();
         }
       
    }

     public static void Delete(int id1)
    {
         MySqlConnection con = new MySqlConnection();
         con.ConnectionString = ConString;
         string query = "delete from Employees where id=@Id";
        
         try{
            MySqlCommand cmd = new MySqlCommand(query,con);
            cmd.Parameters.AddWithValue("@id",id1);
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = query;
            cmd.ExecuteNonQuery();
            
         }catch(Exception e)
         {
            Console.WriteLine(e.Message);
         }finally{
            con.Close();
         }
       
    }


}