create table Employees(Id int,Name varchar(20),Email varchar(50),Contact int);
insert into Employees values(1,"Shubham","shulk@gmail.com",102984756);