namespace BLL;
using BOL;
using DAL;

public class Manager{

    public static List<Employee> GetAll()
    {
        List<Employee> allemp = DBManager.GetAll();
        return allemp;
    }

    public static void Insert(int id1,string name ,string email, int contact)
    {
          DBManager.Insert(id1,name,email,contact);
    }

    public static void Edit(int id1,string name ,string email, int contact)
    {
          DBManager.Edit(id1,name,email,contact);
    }
    
    public static void Delete(int id1)
    {
          DBManager.Delete(id1);
    }


}