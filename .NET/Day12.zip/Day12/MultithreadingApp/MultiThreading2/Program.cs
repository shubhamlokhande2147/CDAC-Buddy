﻿// See https://aka.ms/new-console-template for more information
using util;
using System;

Helper.StoreDate();
Helper.GetRemoteData();

