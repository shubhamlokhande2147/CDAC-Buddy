#include "Shape.h"
#include <iostream>
using namespace std;





Shape::setThikness(int Tk)
		{
			thickness=Tk;
		}
		
Shape::getThikness()
		{
			return thickness;
		}
		



